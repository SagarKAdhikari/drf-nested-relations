from django.apps import AppConfig


class NestedRelationsConfig(AppConfig):
    name = 'nested_relations'
